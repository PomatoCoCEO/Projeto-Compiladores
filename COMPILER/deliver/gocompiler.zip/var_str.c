#include "var_str.h"

char *var_type_strings[] = {
    "", "int", "float32", "bool", "string", "undef", "none"};
