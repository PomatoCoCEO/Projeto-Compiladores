#ifndef VAR_STR_H
#define VAR_STR_H
char *var_type_strings[] = {
    "", "int", "float32", "bool", "string", "undef", "none"};
#endif