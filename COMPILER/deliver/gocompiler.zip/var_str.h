#ifndef VAR_STR_H
#define VAR_STR_H
extern char *var_type_strings[];
#endif